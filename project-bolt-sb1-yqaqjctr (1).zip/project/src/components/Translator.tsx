import React, { useState } from 'react';
import { Cat, Languages } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const catTranslations = {
  'pt-BR': {
    'miau': [
      'Quero comida. Não, não é a mesma de 5 minutos atrás, quero comida NOVA!',
      'Ei, pare de olhar essa tela retangular e me dê atenção AGORA!',
      'Sua audição está funcionando? Minha tigela está vazia há SEGUNDOS!',
      'Humano, você está respirando o MEU ar condicionado!'
    ],
    'miau miau': [
      'Abra a porta! Não, fecha! Não, abre! Não, fecha! Decidir é difícil...',
      'Minha tigela está 97% cheia... isso é praticamente VAZIA!',
      'Tem certeza que já me alimentou hoje? Porque nas últimas 3 horas não me lembro de nada.',
      'Por que você guarda suas roupas naquela gaveta? Claramente é minha nova cama!'
    ],
    'miau miau miau': [
      'EMERGÊNCIA! Achei um pontinho vermelho na parede e ele SUMIU! Chame a polícia!',
      'Acabei de descobrir que minha cauda me segue o tempo todo. Acho que estou sendo perseguido!',
      'Três miados = SOS! O aspirador de pó está me encarando de novo!',
      'Acabo de calcular que dormi apenas 18 horas hoje. Isso é desumano!'
    ],
    'mrrrrrr': [
      'Ahhh, continue com o carinho... mas só por mais 3 segundos, depois vou te morder!',
      'Isso, humano... você está sendo treinado corretamente.',
      'Massagem real para sua majestade felina... Ops, falei isso em voz alta?',
      'Continue assim e talvez eu não derrube seu vaso favorito hoje.'
    ]
  },
  'en-US': {
    'meow': [
      'I want food. No, not the same from 5 minutes ago, I want NEW food!',
      'Hey, stop looking at that rectangular screen and pay attention to me NOW!',
      'Is your hearing working? My bowl has been empty for SECONDS!',
      'Human, you\'re breathing MY air conditioning!'
    ],
    'meow meow': [
      'Open the door! No, close it! No, open! No, close! Decisions are hard...',
      'My bowl is 97% full... that\'s practically EMPTY!',
      'Are you sure you fed me today? Because I don\'t remember anything from the last 3 hours.',
      'Why do you keep your clothes in that drawer? Clearly it\'s my new bed!'
    ],
    'meow meow meow': [
      'EMERGENCY! I found a red dot on the wall and it DISAPPEARED! Call the police!',
      'I just discovered my tail follows me everywhere. I think I\'m being stalked!',
      'Three meows = SOS! The vacuum cleaner is staring at me again!',
      'I just calculated I only slept 18 hours today. This is inhumane!'
    ],
    'purrrr': [
      'Ahhh, keep petting... but only for 3 more seconds, then I\'ll bite you!',
      'That\'s it, human... you\'re being trained correctly.',
      'Royal massage for your feline majesty... Oops, did I say that out loud?',
      'Keep this up and maybe I won\'t knock over your favorite vase today.'
    ]
  }
};

export function Translator() {
  const [input, setInput] = useState('');
  const [translation, setTranslation] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const { language, setLanguage, t } = useLanguage();

  const translateText = () => {
    setIsThinking(true);
    
    setTimeout(() => {
      const translations = catTranslations[language];
      const userInput = language === 'en-US' 
        ? input.toLowerCase().replace('miau', 'meow').replace('mrrrrrr', 'purrrr')
        : input.toLowerCase();

      const possibleTranslations = translations[userInput];
      if (possibleTranslations) {
        const randomIndex = Math.floor(Math.random() * possibleTranslations.length);
        setTranslation(possibleTranslations[randomIndex]);
      } else {
        setTranslation(t('error.not.meow'));
      }
      setIsThinking(false);
    }, 500);
  };

  const toggleLanguage = () => {
    setLanguage(language === 'pt-BR' ? 'en-US' : 'pt-BR');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-100 to-pink-200 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Cat className="w-12 h-12 text-pink-500" />
            <h1 className="text-3xl font-bold text-pink-600 ml-3">
              {t('title')}
            </h1>
          </div>
          <button
            onClick={toggleLanguage}
            className="p-2 text-pink-500 hover:text-pink-600 transition-colors flex items-center gap-2 rounded-lg hover:bg-pink-50"
            title={language === 'pt-BR' ? 'Switch to English' : 'Mudar para Português'}
          >
            <Languages className="w-6 h-6" />
            <span className="text-lg">{language === 'pt-BR' ? '🇧🇷' : '🇺🇸'}</span>
          </button>
        </div>
        
        <div className="space-y-6">
          <div>
            <label htmlFor="text" className="block text-sm font-medium text-gray-700 mb-2">
              {t('input.label')}
            </label>
            <input
              type="text"
              id="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="w-full px-4 py-2 border border-pink-200 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent"
              placeholder={t('input.placeholder')}
            />
          </div>

          <button
            onClick={translateText}
            disabled={isThinking || !input}
            className={`w-full py-3 rounded-lg text-white font-medium transition-all
              ${isThinking || !input 
                ? 'bg-gray-400 cursor-not-allowed' 
                : 'bg-pink-500 hover:bg-pink-600'}`}
          >
            {isThinking ? t('button.thinking') : t('button.translate')}
          </button>

          {translation && (
            <div className="mt-6 p-4 bg-pink-50 rounded-lg border border-pink-100">
              <p className="text-lg text-pink-800 font-medium">{t('translation.title')}</p>
              <p className="mt-2 text-gray-700">{translation}</p>
            </div>
          )}

          <div className="mt-6 text-sm text-gray-500">
            <p>{t('tips.title')}</p>
            <ul className="list-disc list-inside mt-2 space-y-1">
              {language === 'pt-BR' ? (
                <>
                  <li>miau</li>
                  <li>miau miau</li>
                  <li>miau miau miau</li>
                  <li>mrrrrrr</li>
                </>
              ) : (
                <>
                  <li>meow</li>
                  <li>meow meow</li>
                  <li>meow meow meow</li>
                  <li>purrrr</li>
                </>
              )}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}