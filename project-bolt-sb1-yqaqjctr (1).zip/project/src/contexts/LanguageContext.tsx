import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'pt-BR' | 'en-US';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  'pt-BR': {
    'title': 'Tradutor de Miados',
    'input.label': 'Digite o miado do seu gato:',
    'input.placeholder': 'Ex: miau, miau miau, mrrrrrr',
    'button.translate': 'Traduzir',
    'button.thinking': 'Pensando...',
    'translation.title': 'Tradução:',
    'tips.title': 'Dicas de miados para tentar:',
    'error.not.meow': 'Humano, você claramente não fala a língua felina com fluência!',
  },
  'en-US': {
    'title': 'Meow Translator',
    'input.label': 'Type your cat\'s meow:',
    'input.placeholder': 'Ex: meow, meow meow, purrrr',
    'button.translate': 'Translate',
    'button.thinking': 'Thinking...',
    'translation.title': 'Translation:',
    'tips.title': 'Meow tips to try:',
    'error.not.meow': 'Human, you clearly don\'t speak cat language fluently!',
  }
};

const LanguageContext = createContext<LanguageContextType | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('pt-BR');

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}