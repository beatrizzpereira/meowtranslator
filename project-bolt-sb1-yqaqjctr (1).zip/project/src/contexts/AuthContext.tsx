import React, { createContext, useContext, useState, ReactNode } from 'react';

interface AuthContextType {
  isAuthenticated: boolean;
  currentUser: string | null;
  login: (username: string, password: string) => { success: boolean; error?: string };
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState<string | null>(null);

  const validUsers = ['Beatriz', 'Olivia', 'Luis', 'beatriz', 'olivia', 'luis', 'Olívia', 'olívia'];
  const validPassword = 'miau123';

  const login = (username: string, password: string) => {
    const userExists = validUsers.includes(username);
    
    if (!userExists) {
      return { success: false, error: 'Usuário não encontrado! Tente novamente.' };
    }
    
    if (password !== validPassword) {
      return { success: false, error: 'Senha incorreta! Tente novamente.' };
    }
    
    setIsAuthenticated(true);
    setCurrentUser(username.toLowerCase());
    return { success: true };
  };

  const logout = () => {
    setIsAuthenticated(false);
    setCurrentUser(null);
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, currentUser, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}