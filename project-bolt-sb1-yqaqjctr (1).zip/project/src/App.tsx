import React from 'react';
import { LanguageProvider } from './contexts/LanguageContext';
import { Translator } from './components/Translator';

function App() {
  return (
    <LanguageProvider>
      <Translator />
    </LanguageProvider>
  );
}

export default App;